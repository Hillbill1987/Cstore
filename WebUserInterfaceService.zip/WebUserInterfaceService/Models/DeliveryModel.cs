﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebUserInterfaceService.Models
{
    public class DeliveryModel
    {
        public int DeliveryID { get; set; }

        public decimal DeliveryCost { get; set; }

        public string DeliveryMethod { get; set; }

        public DateTime DeliveryDate { get; set; }
    }
}
