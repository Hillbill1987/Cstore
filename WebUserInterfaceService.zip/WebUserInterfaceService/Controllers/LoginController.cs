﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace WebUserInterfaceService.Controllers
{
    [Route("[controller]")]
    public class LoginController : Controller
    {
        [HttpGet]
        [Route("Login")]
        public IActionResult Login()
        {
            return View(new LoginModel());
        }
        [HttpPost]
        [Route("LoginAsync")]
        public async Task<IActionResult> LoginAsync(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                var claims = new List<Claim>();
                if (model.Email == "staff@store.com" && model.Password == "Staff1234!")
                {
                    claims.Add(new Claim(ClaimTypes.Role, "staff"));
                }
                else if (model.Email == "cust@store.com" && model.Password == "Customer1234!")
                {
                    claims.Add(new Claim(ClaimTypes.Role, "customer"));
                }
                else if (model.Email == "shiftman@store.com" && model.Password == "Shift1234!")
                {
                    claims.Add(new Claim(ClaimTypes.Role, "shift_manager"));
                }
                else
                {
                    ModelState.AddModelError("Email", "Email or password is incorrect.");
                }

                var claimsIdentity = new ClaimsIdentity
                (
                    claims,
                    CookieAuthenticationDefaults.AuthenticationScheme
                );

                var authProperties = new AuthenticationProperties()
                {
                    IsPersistent = false,
                    IssuedUtc = DateTime.Now
                };

                await HttpContext.SignInAsync
                (
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties
                );

                return RedirectToAction("Index", "Home");
            }
            return View(model);
        }
        [HttpGet]
        [Route("LogoutAsync")]
        public async Task<IActionResult> LogoutAsync()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("login","Login");
        }
    }

    public class LoginModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
