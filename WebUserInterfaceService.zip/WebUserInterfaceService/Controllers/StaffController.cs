﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Unicode;
using System.Threading.Tasks;
using WebUserInterfaceService.Models;

namespace WebUserInterfaceService.Controllers
{
    [Route("Controller")]
    public class StaffController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public StaffController(IConfiguration configuration, HttpClient httpClient)
        {
            _configuration = configuration;
            _httpClient = httpClient;
        }
        [Authorize(Roles = "shift_manager")]
        public async Task<IActionResult> Index()
        {
            _httpClient.BaseAddress = new Uri(_configuration["StaffUrl"]);
            var response = await _httpClient.GetAsync("");
            var responsebody = await response.Content.ReadAsStringAsync();
            var models = JsonConvert.DeserializeObject<List<StaffModel>>(responsebody);
            return View(models);
        }
        [Authorize(Roles = "shift_manager")]
        [Route("AddStaff")]
        public IActionResult AddStaff()
        {
            return View(new StaffModel());
        }
        [Authorize(Roles = "shift_manager")]
        [HttpPost]
        [Route("AddStaff")]
        public async Task<IActionResult> AddStaff(StaffModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpClient.BaseAddress = new Uri(_configuration["Staffurl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("", content);
            return RedirectToAction("index");
        }
        [Authorize(Roles = "shift_manager")]
        [HttpPost]
        [Route("Updatestaff")]
        public async Task<IActionResult> UpdateStaff(StaffModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpClient.BaseAddress = new Uri(_configuration["StaffUpUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync(model.StaffID.ToString(), content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("UpdateStaff", new { id = model.StaffID });
            }
            return View(model);
        }

        [Authorize(Roles = "shift_manager")]
        [Route("UpdateStaff")]
        public async Task<IActionResult> UpdateStaff(int id)
        {
            _httpClient.BaseAddress = new Uri(_configuration["StaffUrl"]);
            var response = await _httpClient.GetAsync(id.ToString());
            var responsebody = await response.Content.ReadAsStringAsync();
            var model = JsonConvert.DeserializeObject<StaffModel>(responsebody);
            return View(model);
        }

        [Authorize(Roles = "shift_manager")]
        [HttpPost]
        [Route("DeleteStaff")]
        public async Task<IActionResult> DeleteStaff(StaffModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpClient.BaseAddress = new Uri(_configuration["StaffDelUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.DeleteAsync(model.StaffID.ToString());
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("DeleteStaff");
            }
            return View(model);
        }


        [Authorize(Roles ="shift_manager")]
        [Route("DeleteStaff")]
        public async Task<IActionResult> DeleteStaff(int id )
        {
            _httpClient.BaseAddress = new(_configuration["StaffUrl"]);
            var response = await _httpClient.GetAsync(id.ToString());
            var responsebody = await response.Content.ReadAsStringAsync();
            var model = JsonConvert.DeserializeObject<StaffModel>(responsebody);
            return View(model);
        }
    }
}
