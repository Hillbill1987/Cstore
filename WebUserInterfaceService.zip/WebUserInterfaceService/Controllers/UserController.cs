﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using WebUserInterfaceService.Models;

namespace WebUserInterfaceService.Controllers
{
    [Route("[controller]")]
    public class UserController : Controller
    {
        private readonly HttpClient _httpclient;
        private readonly IConfiguration _configuration;

        public UserController(HttpClient httpclient, IConfiguration configuration)
        {
            _httpclient = httpclient;
            _configuration = configuration;
        }
        [Authorize (Roles = "staff")] 
        public async Task <IActionResult> Index()
        {
            _httpclient.BaseAddress = new Uri(_configuration["UserUrl"]);
            var response = await _httpclient.GetAsync("");
            var responsebody = await response.Content.ReadAsStringAsync();
            var models = JsonConvert.DeserializeObject<List<UserModel>>(responsebody);
            return View(models);
        }
        [Authorize(Roles ="staff")]
        [Route("AddUser")]
        public IActionResult AddUser()
        {
            return View(new UserModel());
        }

        [Authorize(Roles = "staff")]
        [HttpPost]
        [Route("AddUser")]
        public async Task <IActionResult> Adduser(UserModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpclient.BaseAddress = new Uri(_configuration["UserUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpclient.PostAsync("", content);
            return RedirectToAction("Index");
        }

        [Authorize(Roles ="staff")]
        [HttpPost]
        [Route("UpdateUser")]
        public async Task <IActionResult> UpdateUser(UserModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpclient.BaseAddress = new Uri(_configuration["UserUpUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpclient.PutAsync(model.UserId.ToString(), content);
            if(response.IsSuccessStatusCode)
            {
                return RedirectToAction("Updateuser", new { id = model.UserId });
            }
            return View(model);
        }

        [Authorize(Roles ="staff")]
        [Route("UpdateUser")]
        public async Task<IActionResult> UpdateUser(int id )
        {
            _httpclient.BaseAddress = new Uri(_configuration["UserUrl"]);
            var response = await _httpclient.GetAsync(id.ToString());
            var responseBody = await response.Content.ReadAsStringAsync();
            var model = JsonConvert.DeserializeObject<UserModel>(responseBody);
            return View(model);
        }
        [Authorize(Roles = "staff")]
        [HttpPost]
        [Route("DeleteUser")]
        public async Task<IActionResult> DeleteUser(UserModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpclient.BaseAddress = new Uri(_configuration["UserDelUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpclient.DeleteAsync(model.UserId.ToString());
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("DeleteUser");
            }
            return View(model);
        }
        [Authorize(Roles = "staff")]
        [Route("DeleteUser")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            _httpclient.BaseAddress = new Uri(_configuration["UserUrl"]);
            var response = await _httpclient.GetAsync(id.ToString());
            var responseBody = await response.Content.ReadAsStringAsync();
            var model = JsonConvert.DeserializeObject<UserModel>(responseBody);
            return View(model);
        }

    }
}
