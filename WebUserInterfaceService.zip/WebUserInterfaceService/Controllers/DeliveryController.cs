﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using WebUserInterfaceService.Models;

namespace WebUserInterfaceService.Controllers
{
    [Route("[controller]")]
    public class DeliveryController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public DeliveryController(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
        }
        [Authorize(Roles = "staff")]
        public async Task <IActionResult> Index()
        {
            _httpClient.BaseAddress = new Uri(_configuration["DeliveryUrl"]);
            var response = await _httpClient.GetAsync("");
            var responsebody = await response.Content.ReadAsStringAsync();
            var models = JsonConvert.DeserializeObject<List<DeliveryModel>>(responsebody);
            return View(models);
        }
       
        [Route("AddDelivery")]
        public IActionResult AddDelivery()
        {
            return View(new DeliveryModel());
        }
        [Authorize(Roles = "staff")]
        [HttpPost]
        [Route("AddDelivery")]
        public async Task <IActionResult> AddDelivery(DeliveryModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpClient.BaseAddress = new Uri(_configuration["DeliveryUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync("",content);
            return RedirectToAction("index");
        }

        [Authorize(Roles = "staff")]
        [HttpPost]
        [Route("UpdateDelivery")]
        public async Task <IActionResult> UpdateDelivery(DeliveryModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpClient.BaseAddress = new Uri(_configuration["DeliveryUpUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.PutAsync(model.DeliveryID.ToString(), content);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("UpdateDelivery", new { id = model.DeliveryID });
            }
            return View(model);
        }
        [Authorize(Roles = "staff")]
        [Route("UpdateDelivery")]
        public async Task<IActionResult> UpdateDelivery(int id)
        {
            _httpClient.BaseAddress = new Uri(_configuration["DeliveryUrl"]);
            var response = await _httpClient.GetAsync(id.ToString());
            var responseBody = await response.Content.ReadAsStringAsync();
            var model = JsonConvert.DeserializeObject<InventoryModel>(responseBody);
            return View(model);
        }

        [Authorize(Roles = "staff")]
        [HttpPost]
        [Route("DeleteDelivery")]
        public async Task<IActionResult> DeleteDelivery(DeliveryModel model)
        {
            var json = JsonConvert.SerializeObject(model);
            _httpClient.BaseAddress = new Uri(_configuration["DeliveryDelUrl"]);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await _httpClient.DeleteAsync(model.DeliveryID.ToString());
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("DeleteDelivery");
            }
            return View(model);
        }
        [Authorize(Roles = "staff")]
        [Route("DeleteDelivery")]
        public async Task<IActionResult> DeleteDelivery(int id)
        {
            _httpClient.BaseAddress = new Uri(_configuration["DeliveryUrl"]);
            var response = await _httpClient.GetAsync(id.ToString());
            var responseBody = await response.Content.ReadAsStringAsync();
            var model = JsonConvert.DeserializeObject<InventoryModel>(responseBody);
            return View(model);
        }

    }
}
